1. place Kuro.ttf in C drive. (C:\Kuro.ttf)
2. Run Kuro.exe
3. Login